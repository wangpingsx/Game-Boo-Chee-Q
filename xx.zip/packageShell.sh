jar cvf xx.jar *.*
mv xx.jar xx.zip
