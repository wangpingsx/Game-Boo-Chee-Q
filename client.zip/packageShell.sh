jar cvf client.jar *.*
mv client.jar client.zip
